# Mensa
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE) 
[![Build Status](https://travis-ci.com/famoser/Mensa.svg?branch=master)](https://travis-ci.com/famoser/Mensa)
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=famoser_Mensa&metric=alert_status)](https://sonarcloud.io/dashboard?id=famoser_Mensa)

eth & uzh mensas in zurich
